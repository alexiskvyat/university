package com.example.pract3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    TextView resultText;
    Button backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        resultText = findViewById(R.id.resultText);
        backBtn = findViewById(R.id.backBtn);

        MyObject obj = (MyObject) getIntent().getSerializableExtra("myObject");
        if (obj != null) {
            String result = "Имя: " + obj.getName() + "\nВозраст: " + obj.getAge();
            resultText.setText(result);
        } else {
            resultText.setText("Данные не получены");
        }

        backBtn.setOnClickListener(v -> finish());
    }
}
