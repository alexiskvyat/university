package com.example.pract3;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class FrameActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frame_sample);

        Button backBtn = findViewById(R.id.backBtnFrame);
        backBtn.setOnClickListener(v -> finish());
    }
}
