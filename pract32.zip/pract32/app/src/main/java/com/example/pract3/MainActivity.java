package com.example.pract3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText nameInput, ageInput;
    Button sendBtn, openFrameBtn, openConstraintBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameInput = findViewById(R.id.editName);
        ageInput = findViewById(R.id.editAge);
        sendBtn = findViewById(R.id.sendBtn);
        openFrameBtn = findViewById(R.id.openFrameBtn);
        openConstraintBtn = findViewById(R.id.openConstraintBtn);

        sendBtn.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String ageStr = ageInput.getText().toString().trim();

            if (name.isEmpty() || ageStr.isEmpty()) {
                Toast.makeText(this, "Введите имя и возраст", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int age = Integer.parseInt(ageStr);
                MyObject obj = new MyObject(name, age);
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("myObject", obj);
                startActivity(intent);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Возраст должен быть числом", Toast.LENGTH_SHORT).show();
            }
        });

        openFrameBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FrameActivity.class);
            startActivity(intent);
        });

        openConstraintBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ConstraintActivity.class);
            startActivity(intent);
        });
    }
}
